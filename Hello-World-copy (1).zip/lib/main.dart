import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(MusicPlayer());
}

class MusicPlayer extends StatelessWidget {
  void playMusic(int num) {
    //create an object
    final player = AudioPlayer();
    //play
    //player.setSource(AssetSource(''));
    player.play(AssetSource('note$num.wav'));
  }

  Expanded buildExpanded({required Color color, required int note}) {
    return Expanded(
      //flex: 2,
      child: TextButton(
        child: Text('Play'),
        onPressed: () {
          playMusic(note);
        },
        style: ButtonStyle(
          foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
          backgroundColor: MaterialStateProperty.all<Color>(color),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text('Music Player'),
          ),
        ),
        body: Column(
          //mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            buildExpanded(color: Colors.white, note: 1),
            buildExpanded(color: Colors.black, note: 2),
            buildExpanded(color: Colors.white, note: 3),
            buildExpanded(color: Colors.black, note: 4),
            buildExpanded(color: Colors.white, note: 5),
            buildExpanded(color: Colors.black, note: 6),
            buildExpanded(color: Colors.white, note: 7),
          ],
        ),
      ),
    );
  }
}
